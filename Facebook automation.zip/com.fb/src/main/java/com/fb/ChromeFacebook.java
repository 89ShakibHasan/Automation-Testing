package com.fb;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;

public class ChromeFacebook {

    public static void main(String[] args) throws InterruptedException {

        // Set ChromeDriver path if needed
        // System.setProperty("webdriver.chrome.driver", "C:\\path\\to\\chromedriver.exe");

        WebDriver driver = new ChromeDriver();

        // Open Facebook
        driver.get("https://www.facebook.com/");
        driver.manage().window().maximize();

        // Enter username
        WebElement emailField = driver.findElement(By.id("email"));
        emailField.sendKeys("your_email_here");

        // Enter password
        WebElement passField = driver.findElement(By.id("pass"));
        passField.sendKeys("your_password_here");

        // ✅ Click Login button
        WebElement loginBtn = driver.findElement(By.name("login"));
        loginBtn.click();

        // Wait a bit
        Thread.sleep(3000);

        // ✅ Click "Forgotten password?" link
        WebElement forgotLink = driver.findElement(By.linkText("Forgotten password?"));
        forgotLink.click();

        // Wait 5 sec to see
        Thread.sleep(5000);

        // Close browser
        driver.quit();
    }
}
